var tabs = document.getElementById('tabs').getElementsByTagName('li');
// console.log(tabs);
var lists = document.getElementById('lists').getElementsByTagName('ul');
// console.log(lists);
// var tab = document.getElementById('tab').getElementsByClassName('li');
// var text = document.getElementById('xiaLa').getElementsByClassName('ul');
for(var i = 0;i<tabs.length;i++){
	tabs[i].onclick = showlist;
	// tab[i].hover = showlist;
}





function showlist(){
	for(var i = 0;i<tabs.length;i++){
		if(tabs[i] === this){
			tabs[i].className = 'active';
			// tab[i].className = 'nav-category';
			lists[i].className = 'clearfix active';
			// xiaLa[i].className = 'text clearfix';
		}
		else{
			tabs[i].className = '';
			lists[i].className = 'clearfix';
// 			tab[i].className = '';
// 			xiaLa[i].className = 'clearfix';
		}
	}
}
var seckillNav = document.getElementById('seckillNav');
window.onscroll = function(){
	// document.body.scrollTop;
	var scrollTop = document.documentElement.scrollTop;
	if(scrollTop >= 260){
		seckillNav.className = 'seckill-nav ';
	}else{
		seckillNav.className = 'seckill-nav';
	}
	// console.log(scrollTop);
}


	var string = document.getElementById("times");
	// var string = document.getElementById("times").style()=innerHeight;
		function fun(n){
			return n > 0 && n < 10 ? '0' + n : '' + n;
		}
		function getDate(){
			 // var  int_hour, int_minute, int_second;   
			 
			var Odate = new Date();
			var OldDate = Odate.getTime();//获取1970年1月1日的毫秒数
			var NDate = new Date('2019/6/20 16:00:00');
			var NewDate = NDate.getTime();//获取目标时间的毫秒数
			var second = Math.floor((NewDate - OldDate)/1000);//获取相差时间的毫秒数

			var day = Math.floor(second / 86400);//24*60*60
			second = second % 86400;
			var hour = Math.floor(second / 3600);
			second = second % 3600;
			var minute = Math.floor(second / 60);
			second = second % 60;

			var str = '即将开始:6月20日'+'<br>'+'距开始:'+ fun(day) + '天'
					+fun(hour)  + '时'
					+fun(minute)  + '分'
					+fun(second) ;
			string.innerHTML = str;
		}
		getDate();
		setInterval(getDate,1000);
		
		
