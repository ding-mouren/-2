$('.show-wrap').each(function(){
			var oLi = $(this).find('.shop-item');
			var height = oLi.height();
			var width = oLi.width();
			var length = oLi.length;
			var col = Math.ceil(length/6);
			$(this).width(col*width);
			oLi.each(function(i){
				var x = Math.floor(i/6);
				var y = i%6;
				$(this).css({
					left:x*width + 'px',
					top: y*height + 'px'
				});
			});
		});
$(document).ready(function(){
  $(".nav-item ").hover(function(){
    $("#xiaLa").slideDown();
  });
});
$(document).ready(function(){
  $(".header").mouseleave(function(){
    $("#xiaLa").slideUp();
	});
});
$(document).ready(function(){
  $(".topbar-cart ").hover(function(){
    $(".cart-box p").slideDown();
	$('.search-form').hide();
  });
});
$(document).ready(function(){
  $(".container ").mouseleave(function(){
    $(".cart-box p").slideUp("slow");
	$('.search-form').show('slow');
  });
});
$(document).ready(function(){
  $(".header-logo").hover(function(){
    $("#xiaLa").slideUp();
	});
});
$(document).ready(function(){
  $(".header-search").hover(function(){
    $("#xiaLa").slideUp('');
	});
});
$(document).ready(function(){
  $(".nav-item1").hover(function(){
    $("#xiaLa").slideUp('');
	});
});
$(document).ready(function(){
  $(".nav-category").hover(function(){
    $("#xiaLa").slideUp();
	});
});
$(document).ready(function(){
	$('.nav-category').hover(function(){
		$('#banner').show();
	});
});
$(document).ready(function(){
	$('.header').mouseleave(function(){
		$('#banner').hide();
	});
});
$(document).ready(function(){
  $(".header-logo").hover(function(){
    $("#banner").hide();
	});
});
$(document).ready(function(){
  $(".header-search").hover(function(){
    $("#banner").hide();
	});
});
$(document).ready(function(){
  $(".nav-item1").hover(function(){
    $("#banner").hide();
	});
});
$(document).ready(function(){
  $(".nav-item").hover(function(){
    $("#banner").hide();
	});
});
