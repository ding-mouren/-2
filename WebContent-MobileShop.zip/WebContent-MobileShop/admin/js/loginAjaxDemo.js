 
 var login = document.getElementById("loginBtn");
 login.addEventListener("click",loginFun);

 function loginFun(){
 	var userName = document.getElementById("userName").value.replace("/(^\s*)|(\s*$)/g","");
 	var password = document.getElementById("password").value.replace("/(^\s*)|(\s*$)/g","");

 	var data = {"input":userName,"password":password};//构建JSON数据

 	var xhr;
 	if(window.XMLHttpRequest){
 		xhr = new XMLHttpRequest();//IE7，Firefox，Chrome，Opear
 	}else{
 		xhr = new ActiveXObject("Microsoft.XMLHTTP");//IE5，IE6浏览器执行代码
 	}

 	var url = "http://localhost:8080/MobileShop " +"/admin_manager/login";
 	xhr.open("POST",url,true);
 	xhr.setRequestHeader("Content-type","application/x-www-form-urlencoded");
 	xhr.send(data);

 	xhr.onreadystatechange = function(){
 		if(xhr.readyState == 4 && xhr.status == 200){//请求成功
 			alert(xhr.responseText);
 		}
 	}
 }